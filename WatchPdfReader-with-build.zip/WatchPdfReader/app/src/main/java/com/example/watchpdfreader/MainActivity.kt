package com.example.watchpdfreader

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Description
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.wear.compose.foundation.lazy.ScalingLazyColumn
import androidx.wear.compose.foundation.lazy.items
import androidx.wear.compose.foundation.lazy.itemsIndexed
import androidx.wear.compose.material.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                WatchPdfApp()
            }
        }
    }
}

@Composable
fun WatchPdfApp() {
    val context = LocalContext.current
    var hasPermission by remember { mutableStateOf(checkStoragePermission()) }
    var selectedFile by remember { mutableStateOf<File?>(null) }

    if (!hasPermission) {
        PermissionScreen(
            onRequestPermission = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                        data = Uri.parse("package:${context.packageName}")
                    }
                    context.startActivity(intent)
                }
            },
            onRefresh = { hasPermission = checkStoragePermission() }
        )
    } else if (selectedFile == null) {
        PdfFileListScreen(onFileSelected = { selectedFile = it })
    } else {
        PdfReaderScreen(
            file = selectedFile!!,
            onBack = { selectedFile = null }
        )
    }
}

fun checkStoragePermission(): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        Environment.isExternalStorageManager()
    } else {
        true
    }
}

@Composable
fun PermissionScreen(onRequestPermission: () -> Unit, onRefresh: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("PDF পড়ার জন্য Storage Permission দিন", fontSize = 12.sp, color = Color.White)
        Spacer(modifier = Modifier.height(10.dp))
        CompactChip(
            onClick = onRequestPermission,
            label = { Text("Grant Access") }
        )
        Spacer(modifier = Modifier.height(6.dp))
        CompactChip(
            onClick = onRefresh,
            label = { Text("Refresh") }
        )
    }
}

fun getPdfFiles(): List<File> {
    val pdfList = mutableListOf<File>()
    val dirs = listOf(
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
    )
    for (dir in dirs) {
        if (dir != null && dir.exists() && dir.isDirectory) {
            dir.walkTopDown().forEach { file ->
                if (file.isFile && file.extension.equals("pdf", ignoreCase = true)) {
                    pdfList.add(file)
                }
            }
        }
    }
    return pdfList.sortedByDescending { it.lastModified() }
}

@Composable
fun PdfFileListScreen(onFileSelected: (File) -> Unit) {
    var pdfFiles by remember { mutableStateOf<List<File>>(emptyList()) }

    LaunchedEffect(Unit) {
        pdfFiles = withContext(Dispatchers.IO) { getPdfFiles() }
    }

    Scaffold(
        timeText = { TimeText() }
    ) {
        if (pdfFiles.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "Download বা Documents ফোল্ডারে কোনো PDF পাওয়া যায়নি।",
                    fontSize = 12.sp,
                    color = Color.LightGray
                )
            }
        } else {
            ScalingLazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black),
                contentPadding = PaddingValues(top = 28.dp, bottom = 28.dp, start = 10.dp, end = 10.dp)
            ) {
                item {
                    Text(
                        text = "My PDFs (${pdfFiles.size})",
                        fontSize = 14.sp,
                        color = Color(0xFF8AB4F8),
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
                items(pdfFiles) { file ->
                    Chip(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        onClick = { onFileSelected(file) },
                        label = {
                            Text(
                                text = file.name,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                fontSize = 13.sp
                            )
                        },
                        secondaryLabel = {
                            Text(
                                text = file.parentFile?.name ?: "",
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                        },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Description,
                                contentDescription = "PDF",
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun PdfReaderScreen(file: File, onBack: () -> Unit) {
    val rendererMutex = remember { Mutex() }
    var pdfRenderer by remember { mutableStateOf<PdfRenderer?>(null) }
    var fileDescriptor by remember { mutableStateOf<ParcelFileDescriptor?>(null) }
    var pageCount by remember { mutableIntStateOf(0) }
    var currentPage by remember { mutableIntStateOf(0) }
    var showPageOverview by remember { mutableStateOf(false) }

    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var renderedBitmap by remember { mutableStateOf<Bitmap?>(null) }

    val configuration = LocalConfiguration.current
    val density = LocalDensity.current
    val screenWidthPx = with(density) { configuration.screenWidthDp.dp.toPx().toInt() }

    DisposableEffect(file) {
        try {
            val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            val renderer = PdfRenderer(pfd)
            fileDescriptor = pfd
            pdfRenderer = renderer
            pageCount = renderer.pageCount
        } catch (e: Exception) {
            e.printStackTrace()
        }
        onDispose {
            try {
                pdfRenderer?.close()
                fileDescriptor?.close()
            } catch (_: Exception) {}
        }
    }

    LaunchedEffect(pdfRenderer, currentPage, scale) {
        val renderer = pdfRenderer ?: return@LaunchedEffect
        if (pageCount <= 0) return@LaunchedEffect

        if (scale > 1.2f) delay(150)

        val renderMultiplier = scale.coerceIn(1.5f, 3.5f)
        val bitmap = withContext(Dispatchers.IO) {
            rendererMutex.withLock {
                try {
                    val page = renderer.openPage(currentPage)
                    val targetWidth = (screenWidthPx * renderMultiplier).toInt().coerceAtMost(2000)
                    val targetHeight = (targetWidth.toFloat() / page.width * page.height).toInt().coerceAtLeast(1)
                    val bmp = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(AndroidColor.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    page.close()
                    bmp
                } catch (e: Exception) {
                    null
                }
            }
        }
        if (bitmap != null) {
            renderedBitmap = bitmap
        }
    }

    if (showPageOverview && pdfRenderer != null) {
        PageOverviewScreen(
            pdfRenderer = pdfRenderer!!,
            rendererMutex = rendererMutex,
            pageCount = pageCount,
            currentPage = currentPage,
            onPageSelected = { selectedIndex ->
                currentPage = selectedIndex
                scale = 1f
                offset = Offset.Zero
                showPageOverview = false
            },
            onClose = { showPageOverview = false }
        )
    } else {
        var accumulatedSwipeX by remember { mutableFloatStateOf(0f) }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .pointerInput(Unit) {
                    detectTapGestures(
                        onDoubleTap = {
                            if (scale > 1.1f) {
                                scale = 1f
                                offset = Offset.Zero
                            } else {
                                scale = 2.5f
                                offset = Offset.Zero
                            }
                        }
                    )
                }
                .pointerInput(currentPage, pageCount) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        val newScale = (scale * zoom).coerceIn(1f, 4f)
                        scale = newScale

                        if (scale > 1.05f) {
                            accumulatedSwipeX = 0f
                            val maxOffset = (screenWidthPx * (scale - 1f)) / 1.5f
                            offset = Offset(
                                x = (offset.x + pan.x).coerceIn(-maxOffset, maxOffset),
                                y = (offset.y + pan.y).coerceIn(-maxOffset, maxOffset)
                            )
                        } else {
                            offset = Offset.Zero
                            accumulatedSwipeX += pan.x
                            val swipeThreshold = 85f
                            if (abs(accumulatedSwipeX) > swipeThreshold) {
                                if (accumulatedSwipeX < -swipeThreshold && currentPage < pageCount - 1) {
                                    currentPage++
                                } else if (accumulatedSwipeX > swipeThreshold && currentPage > 0) {
                                    currentPage--
                                }
                                accumulatedSwipeX = 0f
                            }
                        }
                    }
                }
        ) {
            renderedBitmap?.let { bmp ->
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = "PDF Page ${currentPage + 1}",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer(
                            scaleX = scale,
                            scaleY = scale,
                            translationX = offset.x,
                            translationY = offset.y
                        )
                )
            }

            Row(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 8.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black.copy(alpha = 0.72f))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White,
                    modifier = Modifier
                        .size(16.dp)
                        .clickable { onBack() }
                )
                Spacer(modifier = Modifier.width(10.dp))
                Row(
                    modifier = Modifier.clickable { showPageOverview = true },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.List,
                        contentDescription = "Pages",
                        tint = Color(0xFF8AB4F8),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${currentPage + 1}/$pageCount",
                        color = Color.White,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
fun PageOverviewScreen(
    pdfRenderer: PdfRenderer,
    rendererMutex: Mutex,
    pageCount: Int,
    currentPage: Int,
    onPageSelected: (Int) -> Unit,
    onClose: () -> Unit
) {
    val pages = remember(pageCount) { (0 until pageCount).toList() }

    ScalingLazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
        contentPadding = PaddingValues(top = 24.dp, bottom = 24.dp, start = 12.dp, end = 12.dp)
    ) {
        item {
            CompactChip(
                onClick = onClose,
                label = { Text("Close Preview", fontSize = 11.sp) },
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
        itemsIndexed(pages) { index, _ ->
            var thumbBitmap by remember(index) { mutableStateOf<Bitmap?>(null) }

            LaunchedEffect(index) {
                thumbBitmap = withContext(Dispatchers.IO) {
                    rendererMutex.withLock {
                        try {
                            val page = pdfRenderer.openPage(index)
                            val w = 90
                            val h = (w.toFloat() / page.width * page.height).toInt().coerceAtLeast(1)
                            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                            bmp.eraseColor(AndroidColor.WHITE)
                            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            page.close()
                            bmp
                        } catch (e: Exception) {
                            null
                        }
                    }
                }
            }

            val isCurrent = index == currentPage
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isCurrent) Color(0xFF1E3A5F) else Color(0xFF1F1F1F))
                    .clickable { onPageSelected(index) }
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(width = 36.dp, height = 48.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.DarkGray),
                    contentAlignment = Alignment.Center
                ) {
                    thumbBitmap?.let {
                        Image(
                            bitmap = it.asImageBitmap(),
                            contentDescription = "Page ${index + 1} preview",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Page ${index + 1}",
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    if (isCurrent) {
                        Text(
                            text = "Current",
                            color = Color(0xFF8AB4F8),
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }
}
