# WatchPdfReader (Wear OS / Galaxy Watch)

## How to Build APK in Android Studio
1. Unzip `WatchPdfReader.zip`.
2. Open **Android Studio** -> **Open** -> Select the `WatchPdfReader` folder.
3. Wait for Gradle Sync to finish (it will automatically download dependencies).
4. To build an APK: Go to **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
   - The generated APK will be in `app/build/outputs/apk/debug/app-debug.apk`.
5. Install on Galaxy Watch via ADB:
   ```bash
   adb connect <WATCH_IP>:<PORT>
   adb install app/build/outputs/apk/debug/app-debug.apk
   adb shell appops set com.example.watchpdfreader MANAGE_EXTERNAL_STORAGE allow
   ```
